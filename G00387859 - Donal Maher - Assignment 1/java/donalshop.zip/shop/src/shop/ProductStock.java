package shop;

import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
/**
 * 
 * @author Donal Maher
 *
 */
public interface ProductStock {
	// Initializing a Dictionary 
    HashMap<String, Integer> shopStock = new HashMap<String, Integer>();
	//Dictionary<String, Integer> shopStock = new Hashtable<String, Integer>();
    //Dictionary<String, Double> shopPrice = new Hashtable<String, Double>();
    HashMap<String, Double> shopPrice = new HashMap<String, Double>();
   
    

    	
    }

